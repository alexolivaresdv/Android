package alexolivares.pruebapp3alex;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText nombre, numero1, numero2, numero3;
    private Button promedio;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombre = (EditText)findViewById(R.id.txtnombre);
        numero1 = (EditText)findViewById(R.id.txtnumero1);
        numero2 = (EditText)findViewById(R.id.txtnumero2);
        numero3 = (EditText)findViewById(R.id.txtnumero3);
        promedio = (Button)findViewById(R.id.btnpromedio);

        promedio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float num1 = Float.parseFloat(numero1.getText().toString());
                float num2 = Float.parseFloat(numero2.getText().toString());
                float num3 = Float.parseFloat(numero3.getText().toString());
                float promedio = (num1 + num2 + num3) / 3;
                mostrar(promedio);

            }
        });



    }
    private void mostrar(float valor)


    {
        Toast.makeText(this,  "Su Promedio es  "+valor, Toast.LENGTH_LONG).show();
    }

}

