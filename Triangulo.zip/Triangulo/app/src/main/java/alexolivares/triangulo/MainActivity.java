package alexolivares.triangulo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText numero1, numero2, numero3;
    private Button calcular, calcular2;
    float PI = 3.14f;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numero1 = (EditText)findViewById(R.id.txtbase);
        numero2 = (EditText)findViewById(R.id.txtaltura);
        numero3 = (EditText)findViewById(R.id.txtradio);
        calcular = (Button)findViewById(R.id.btncalcular);
        calcular2 = (Button)findViewById(R.id.btncalcular2);


        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float num1 = Integer.parseInt(numero1.getText().toString());
                float num2 = Integer.parseInt(numero2.getText().toString());
                float cal = num1 * num2 / 2;
                mostrar(cal);
            }
        });

        calcular2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float num3 = Integer.parseInt(numero3.getText().toString());
                float cal2 = (PI *(num3 * num3)) / 2;
                mostrar(cal2);
            }
        });




    }
    private void mostrar(float valor)

    {
        Toast.makeText(this, "Resultado "+valor, Toast.LENGTH_LONG).show();
    }

}

