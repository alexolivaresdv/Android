package alexolivares.bdsqlite;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText codigo, producto, valor;
    private Button crear, consultar, modificar, eliminar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        codigo = (EditText)findViewById(R.id.codigo);
        producto = (EditText)findViewById(R.id.producto);
        valor = (EditText)findViewById(R.id.valor);

        crear = (Button)findViewById(R.id.btncrear);
        consultar = (Button)findViewById(R.id.btnconsultar);
        modificar = (Button)findViewById(R.id.btnmodificar);
        eliminar = (Button)findViewById(R.id.btneliminar);

        crear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                crear();
            }
        });
    }
    public void crear()
    {
        //Creamos un objeto para manipular la BD.
        SQLite sqLite = new SQLite(this, "administracion", null, 1);
        SQLiteDatabase bd= sqLite.getWritableDatabase();

        //creamos 3 variables para guardar los valores de entrada
        String cod = codigo.getText().toString();
        String desc = producto.getText().toString();
        String val = valor.getText().toString();

        //Creamos un contenedor para almacenar los valores
        ContentValues registro = new ContentValues();

        //Ponemos los valores en el contenedor
        registro.put("codigo", cod);
        registro.put("producto", desc);
        registro.put("valor", val);

        //Guardamos los valores
        bd.insert("articulo", null, registro);
        bd.close();

        //Limpiar los campos para una nueva operacion
        codigo.setText("");
        producto.setText("");
        valor.setText("");

        //Imprimir el resultado por pantalla
        Toast.makeText(this, "Se cargaron todos los datos", Toast.LENGTH_SHORT).show();
    }
}
