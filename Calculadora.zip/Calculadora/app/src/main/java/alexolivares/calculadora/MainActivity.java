package alexolivares.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText numero1, numero2;
    private Button sumar, restar, multiplicar, dividir;
    ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numero1 = (EditText)findViewById(R.id.txtnumero1);
        numero2 = (EditText)findViewById(R.id.txtnumero2);
        sumar = (Button)findViewById(R.id.btnSumar);
        restar = (Button)findViewById(R.id.btnRestar);
        multiplicar = (Button)findViewById(R.id.btnMultiplicar);
        dividir = (Button)findViewById(R.id.btnDividir);

        sumar.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View view) {
                                         int num1 = Integer.parseInt(numero1.getText().toString());
                                         int num2 = Integer.parseInt(numero2.getText().toString());
                                         int suma = num1 + num2;
                                         mostrar(suma);
                                     }
                                 });

        restar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1 = Integer.parseInt(numero1.getText().toString());
                int num2 = Integer.parseInt(numero2.getText().toString());
                int resta = num1 - num2;
                mostrar(resta);
            }
        });

        multiplicar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1 = Integer.parseInt(numero1.getText().toString());
                int num2 = Integer.parseInt(numero2.getText().toString());
                int multiplicar = num1 * num2;
                mostrar(multiplicar);
            }
        });

        dividir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1 = Integer.parseInt(numero1.getText().toString());
                int num2 = Integer.parseInt(numero2.getText().toString());
                int dividir = num1 / num2;
                mostrar(dividir);
            }
        });


    }
    private void mostrar(int valor)

    {
        Toast.makeText(this, "Resultado "+valor, Toast.LENGTH_LONG).show();
    }

}

